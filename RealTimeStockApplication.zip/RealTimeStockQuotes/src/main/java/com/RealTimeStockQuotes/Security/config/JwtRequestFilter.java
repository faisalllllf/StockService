package com.RealTimeStockQuotes.Security.config;



import io.jsonwebtoken.ExpiredJwtException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;



import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {
	private static final Logger logger = LoggerFactory.getLogger(JwtRequestFilter.class);

	@Autowired
	private CustomUserDetailsService userDetailsService;

	@Autowired
	private JwtUtil jwtUtil;

	@Override
	protected void doFilterInternal(jakarta.servlet.http.HttpServletRequest request,
			jakarta.servlet.http.HttpServletResponse response, jakarta.servlet.FilterChain filterChain)
			throws jakarta.servlet.ServletException, IOException {
		final String authorizationHeader = request.getHeader("Authorization");
		logger.info("insdide authentication ");
		String username = null;
		String jwtToken = null;
		if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
			jwtToken = authorizationHeader.substring(7);
			logger.info("authorizationHeader :" + authorizationHeader);
			try {
				username = jwtUtil.extractUsername(jwtToken);
				logger.info("sucessfull authentication for:" + username);
			} catch (ExpiredJwtException e) {
				logger.warn("JWT Token has expired");
			}
		}

		// Once we get the token validate it.
		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			logger.info(" authenticating with db for:" + username);
			UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);
			logger.info("  userdetails by  token completed" + userDetails.toString());
			
			if (jwtUtil.validateToken(jwtToken, userDetails)) {
				logger.info(" valiting token  for:" + username);
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				usernamePasswordAuthenticationToken
						.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
				logger.info(" valiting completed  for:" + username);
			}
		}
		logger.info(" filterchain invoked   for:" + username);
		filterChain.doFilter(request, response);
	}
}