package com.RealTimeStockQuotes.Security.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.RealTimeStockQuotes.Security.dto.UserDto;
import com.RealTimeStockQuotes.Security.model.User;
import com.RealTimeStockQuotes.Security.repo.UserRepository;
import com.RealTimeStockQuotes.Service.RealTimeStockService;

@Service
public class UserService {
	private static final Logger logger = LoggerFactory.getLogger(UserService.class);

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserRepository userRepository;

	public void saveUser(UserDto userDto) {
		logger.info("saving credentilas in db ");
		User user = new User();
		user.setUsername(userDto.getUsername());
		user.setPassword(passwordEncoder.encode(userDto.getPassword()));

		userRepository.save(user);
	}
}
