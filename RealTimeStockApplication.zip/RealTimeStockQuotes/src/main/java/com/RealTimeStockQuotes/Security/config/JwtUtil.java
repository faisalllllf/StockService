package com.RealTimeStockQuotes.Security.config;




import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.RealTimeStockQuotes.Security.model.TokenEntity;
import com.RealTimeStockQuotes.Security.repo.TokenRepository;

import io.jsonwebtoken.security.Keys;

import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;

import java.security.Key;

@Component
public class JwtUtil {
	private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);


	private int expiration = 7200; 

	//private Key key = Keys.secretKeyFor(SignatureAlgorithm.HS512);
	private static final String SECRET_KEY = "AReallyReallyREallyReallyREallySecureJWTKey202AReallyReallyREallyReallyREallySecureJWTKey20244!!";
	
	private SecretKey key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes()); 
	
	@Autowired
	private TokenRepository tokenRepository; // Your repository to access tokens
	// Generate JWT token and store in database

	public String generateToken(UserDetails userDetails) {
		// Check if token already exists in database
		TokenEntity existingToken = tokenRepository.findByUsername(userDetails.getUsername());
		logger.info("genrating token method");
		if (existingToken != null && isValid(existingToken)) {
			logger.info("not generating token method as it si not expired yet");
			return existingToken.getToken(); // Return existing token if valid
		}
		logger.info("genrating new method");
		
		// Generate new token
		Date now = new Date();
		Date expiryDate = new Date(now.getTime() + expiration * 1000);

		String newToken = Jwts.builder().setSubject(userDetails.getUsername()).setIssuedAt(now)
				.setExpiration(expiryDate).signWith(key,SignatureAlgorithm.HS256).compact();

		// Save new token in database
		if (existingToken != null) {
			existingToken.setToken(newToken);
			existingToken.setExpiryDate(expiryDate);
		} else {
			existingToken = new TokenEntity(userDetails.getUsername(), newToken, expiryDate);
		}
		logger.info("saving new  token in db");

		tokenRepository.save(existingToken);
		logger.info("saved  token succesfull");

		return newToken;
	}

	// Check if the token is still valid
	private boolean isValid(TokenEntity token) {
		return token.getExpiryDate() != null && token.getExpiryDate().after(new Date());
	}

	public boolean validateToken(String token, UserDetails userDetails) {
		final String username = extractUsername(token);
		logger.debug("every thing is working fine");
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}

	public String extractUsername(String token) {
		logger.info("token  :"+token);
		logger.info("key"+key.toString());
		return extractClaim(token, Claims::getSubject);
	}

	public Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	private <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		logger.info("token parsed is"+token);
		
		return claimsResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		logger.info("extracting token "+token);
		Claims claim= Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
		logger.info("Extracting token completed");
		return claim;
	}

	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}
}

