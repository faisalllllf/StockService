package com.RealTimeStockQuotes.model;

import java.time.LocalDateTime;

import lombok.Data;

public class ErrorResponse {
	 private int statusCode;
	    private String message;
	    private LocalDateTime timeStamp;
		@Override
		public String toString() {
			return "ErrorResponse [statusCode=" + statusCode + ", message=" + message + ", timeStamp=" + timeStamp
					+ "]";
		}
		public int getStatusCode() {
			return statusCode;
		}
		public void setStatusCode(int statusCode) {
			this.statusCode = statusCode;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public LocalDateTime getTimeStamp() {
			return timeStamp;
		}
		public void setTimeStamp(LocalDateTime timeStamp) {
			this.timeStamp = timeStamp;
		}
	    
	    
	    
}
