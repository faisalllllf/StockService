package com.RealTimeStockQuotes.Exception;

public class QuoteNotFoundException extends Exception {

	public QuoteNotFoundException(String msg) {
		super(msg);
	}

	public QuoteNotFoundException(String msg, Throwable t) {
		super(msg, t);

	}
}
