package com.RealTimeStockQuotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.RealTimeStockQuotes.Security.config.JwtUtil;

@SpringBootApplication
public class RealTimeStockQuotesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealTimeStockQuotesApplication.class, args);
		
		
	}

}
