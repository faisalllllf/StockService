package com.RealTimeStockQuotes.Controller;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

import org.slf4j.Logger;

import com.RealTimeStockQuotes.Exception.QuoteNotFoundException;
import com.RealTimeStockQuotes.Service.RealTimeStockService;
import com.RealTimeStockQuotes.model.RealTimeQuoteModel;

@RestController
@RequestMapping("/realTimeStocks")
public class RealTimeStockController {
	private static final Logger logger = LoggerFactory.getLogger(RealTimeStockController.class);

	@Autowired
	private RealTimeStockService realTimeStockService;

	@GetMapping("/getquote/{QuoteSymbol}")
	public ResponseEntity<RealTimeQuoteModel> getRealTimeQuote(@PathVariable("QuoteSymbol") String QuoteSymbol)
			throws QuoteNotFoundException {

		logger.debug("get Real time stock Quote Invoked");
		logger.debug("GET /realTimeStocks/getquote/{}", QuoteSymbol);
		RealTimeQuoteModel realTimeQuoteModel = new RealTimeQuoteModel();
		try {

			realTimeQuoteModel = realTimeStockService.getQuoteByStockSymbol(QuoteSymbol);

			return ResponseEntity.status(HttpStatus.OK).body(realTimeQuoteModel);
		} catch (QuoteNotFoundException e) {
			logger.debug("Exception Occured at get real time stock quote for symbol " + QuoteSymbol);
			throw e;
		} catch (Exception e) {
			// Handle other unexpected exceptions
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}

	}

	@GetMapping("/getMultipleQuotes")
	public ResponseEntity<Map<String, RealTimeQuoteModel>> getAllRealTimeQuote(
			@RequestParam("QuoteSymbols") String[] QuoteSymbols) throws QuoteNotFoundException {

		logger.debug("get Real time stock Quote Invoked");

		try {

			Map<String, RealTimeQuoteModel> realTimeQuoteModel = realTimeStockService.getMultipleQuotes(QuoteSymbols);

			return ResponseEntity.status(HttpStatus.OK).body(realTimeQuoteModel);

		} catch (QuoteNotFoundException e) {
			logger.debug("Exception Occured at multiple stock Quote");
			throw e;
		} catch (Exception e) {
			// Handle other unexpected exceptions
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}
}
