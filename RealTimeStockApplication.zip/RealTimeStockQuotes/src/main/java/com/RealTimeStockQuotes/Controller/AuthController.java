package com.RealTimeStockQuotes.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.RealTimeStockQuotes.Security.config.CustomUserDetailsService;
import com.RealTimeStockQuotes.Security.config.JwtUtil;
import com.RealTimeStockQuotes.Security.dto.UserDto;
import com.RealTimeStockQuotes.Security.repo.UserRepository;
import com.RealTimeStockQuotes.Security.service.UserService;

@RestController
@RequestMapping("/auth")
public class AuthController {

	private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private UserService userservice;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private CustomUserDetailsService userDetailsService;

	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody UserDto userdto) throws Exception {

		logger.debug("userdto" + userdto);
		try {

			userservice.saveUser(userdto);

			// userRepository.save(employee);
		} catch (Exception e) {
			logger.error("exception during saving in db");
			return ResponseEntity.status(401).body("exception during saving in db");

		}
		logger.info("testing");

		return ResponseEntity
				.ok("user created sucesfull Now login with these and use genearted jwt token to use stock apis");
	}

	@GetMapping("/login")
	public ResponseEntity<String> login(@RequestBody UserDto userdto) throws Exception {
		logger.info("IN login validate ");
		logger.info("authenticationRequest" + userdto.toString());
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(userdto.getUsername(), userdto.getPassword()));
		} catch (BadCredentialsException e) {
			logger.error("Incorrect username or password");
			return ResponseEntity.status(401).body("Incorrect username or password");
			// throw new Exception("Incorrect username or password", e);

		}
		logger.info("testing");
		final UserDetails userDetails = userDetailsService.loadUserByUsername(userdto.getUsername());
		logger.info("fetch username completed");
		final String token = jwtUtil.generateToken(userDetails);
		logger.info("token" + token);

		return ResponseEntity.ok(token);
	}
	

}
