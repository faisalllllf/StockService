package com.RealTimeStockQuotes.Service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.RealTimeStockQuotes.Exception.QuoteNotFoundException;
import com.RealTimeStockQuotes.model.RealTimeQuoteModel;

@Service
public class RealTimeStockService {

	private static final Logger logger = LoggerFactory.getLogger(RealTimeStockService.class);

	@Autowired
	private RestTemplate restTemplate;
	@Value("${apiurl}")
	private String vantageApiUrl;

	@Value("${apikey}")
	private String vantageapiKey;

	@Cacheable(value = "realTimeStockQuotes", key = "#StockSymbol")
	public RealTimeQuoteModel getQuoteByStockSymbol(String StockSymbol) throws QuoteNotFoundException {
		logger.debug("Getting  stock quote details for StockSymbols: {}", StockSymbol);
	//	String url =vantageApiUrl + "?StockSymbol=" + StockSymbol + "&apikey=" + vantageapiKey;
		//https://eodhd.com/api/real-time/AAPL.US?api_token=&fmt=json
		
		String url = vantageApiUrl + StockSymbol + "?api_token=" + vantageapiKey + "&fmt=" + "json";
		RealTimeQuoteModel realTimeQuoteModel = restTemplate.getForObject(url, RealTimeQuoteModel.class);
		if (realTimeQuoteModel != null) {
			logger.debug("Getting  stock quote details for StockSymbol completed sucessfully for StockSymbol : {}",
					StockSymbol, realTimeQuoteModel);
			return realTimeQuoteModel;
		} else {
			logger.error("Exception while getting details for StockSymbol: {}", StockSymbol, realTimeQuoteModel);
			throw new QuoteNotFoundException("Exception while getting details for StockSymbol" + StockSymbol);
		}

	}

	//@Cacheable(value = "realTimeStockQuotes", key = "#StockSymbolss.toString()")
	public Map<String, RealTimeQuoteModel> getMultipleQuotes(String[] StockSymbols) throws QuoteNotFoundException {
		logger.debug("Fetching stock quotes for  multiple StockSymbolss Started: {}", StockSymbols.toString());
		Map<String, RealTimeQuoteModel> repsonsestockQuotes = new HashMap<>();

		for (String StockSymbol : StockSymbols) {

			String url = vantageApiUrl + StockSymbol + "?api_token=" + vantageapiKey + "&fmt=" + "json";

			RealTimeQuoteModel realTimeQuoteModel = restTemplate.getForObject(url, RealTimeQuoteModel.class);
			if (realTimeQuoteModel != null) {
				repsonsestockQuotes.put(StockSymbol, realTimeQuoteModel);
			} else {
				logger.error("Exception while getting details for StockSymbols: {}", StockSymbols, realTimeQuoteModel);
				throw new QuoteNotFoundException(
						"Exception while getting details for StockSymbols inside Mupltiple StocksQuotess"
								+ StockSymbols);
			}

		}
		logger.debug(
				"Getting  stock quote details for Multiple StockSymbols completed sucessfully for StockSymbols : {}",
				StockSymbols, repsonsestockQuotes);
		return repsonsestockQuotes;
	}

}
