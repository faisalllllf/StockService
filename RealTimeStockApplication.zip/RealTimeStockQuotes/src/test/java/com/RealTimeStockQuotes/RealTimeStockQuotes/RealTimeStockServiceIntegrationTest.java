package com.RealTimeStockQuotes.RealTimeStockQuotes;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;

import com.RealTimeStockQuotes.Exception.QuoteNotFoundException;
import com.RealTimeStockQuotes.Service.RealTimeStockService;
import com.RealTimeStockQuotes.model.RealTimeQuoteModel;

@SpringBootTest
@EnableCaching
public class RealTimeStockServiceIntegrationTest {

    @Autowired
    private RealTimeStockService realTimeStockService; // Replace with your actual service class

    @Autowired
    private CacheManager cacheManager;

    @Test
    public void testGetQuote() throws QuoteNotFoundException {
        String stockSymbol = "AAPL";

        
        RealTimeQuoteModel result = realTimeStockService.getQuoteByStockSymbol(stockSymbol);

        assertThat(result).isNotNull();
        
        // Check if the cache has the value
        assertThat(cacheManager.getCache("realTimeStockQuotes").get(stockSymbol)).isNotNull();
    }

    @Test
    public void testCacheBehaviour() throws QuoteNotFoundException {
        String stockSymbol = "AAPL";

        // First call to populate the cache
        realTimeStockService.getQuoteByStockSymbol(stockSymbol);

        // Verify cache is populated
        assertThat(cacheManager.getCache("realTimeStockQuotes").get(stockSymbol)).isNotNull();

        // Clear cache and make another call to verify cache behavior
        cacheManager.getCache("realTimeStockQuotes").clear();
        assertThat(cacheManager.getCache("realTimeStockQuotes").get(stockSymbol)).isNull();
    }
}
